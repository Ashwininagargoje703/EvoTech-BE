module.exports = {
    getMongoConnectionString(){
        return 'mongodb+srv://cheeku:cheekuji@cluster0.bvdwy.mongodb.net/manijment-api'
    }
}
